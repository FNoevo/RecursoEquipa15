package launcher;

import recurso.MainApp;


import java.io.Serializable;

import javafx.application.Application;


public class JavaFxLauncher {
	public static void main(String[]args) {
		//Application.launch(EsbocoTabela.class,args);
		Application.launch(MainApp.class,args);
		//Application.launch(OrcamentoTabela.class,args);
		//Application.launch(AdminTabela.class,args);
	}

}
	