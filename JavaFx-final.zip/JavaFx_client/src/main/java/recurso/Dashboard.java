package recurso;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import pt.upt.ei.lp.model.*;
import pt.upt.ei.lp.model.Tarefa.Priority;
import pt.upt.ei.lp.model.Tarefa.Status;
import pt.upt.ei.lp.rest.TarefaRestClient;

import java.time.LocalDate;
import java.util.List;

public class Dashboard {

    private static ObservableList<Tarefa> tarefasList = FXCollections.observableArrayList();
    private static TarefaRestClient tarefaRestClient = new TarefaRestClient();
    private static Long usuarioAtualId;
    private static boolean isUpdating = false;

    public static void display(Long userId) {
        usuarioAtualId = userId;
        Stage stage = new Stage();
        stage.setTitle("Gestão de Tarefas");

        TableView<Tarefa> tableView = new TableView<>();
        TableColumn<Tarefa, String> colunaTitulo = new TableColumn<>("Título");
        colunaTitulo.setCellValueFactory(cellData -> cellData.getValue().tituloProperty());

        TableColumn<Tarefa, String> colunaDescricao = new TableColumn<>("Descrição");
        colunaDescricao.setCellValueFactory(cellData -> cellData.getValue().descricaoProperty());

        TableColumn<Tarefa, Priority> colunaPrioridade = new TableColumn<>("Prioridade");
        colunaPrioridade.setCellValueFactory(cellData -> cellData.getValue().prioridadeProperty());

        TableColumn<Tarefa, Status> colunaStatus = new TableColumn<>("Status");
        colunaStatus.setCellValueFactory(cellData -> cellData.getValue().estadoProperty());
        
        TableColumn<Tarefa, LocalDate> colunaDataInicio = new TableColumn<>("Data Início");
        colunaDataInicio.setCellValueFactory(cellData -> cellData.getValue().dataInicioProperty());
        
        TableColumn<Tarefa, LocalDate> colunaDataFim = new TableColumn<>("Data Fim");
        colunaDataFim.setCellValueFactory(cellData -> cellData.getValue().dataFimProperty());

        tableView.getColumns().addAll(colunaTitulo, colunaDescricao, colunaPrioridade, colunaStatus, colunaDataInicio, colunaDataFim);
        tableView.setItems(tarefasList);

        Button btnAdicionar = new Button("Adicionar");
        Button btnAtualizar = new Button("Atualizar");
        Button btnRemover = new Button("Remover");
        Button btnConcluir = new Button("Marcar como Concluída");
        Button btnListarStatus = new Button("Listar por Status");
        Button btnListarPrioridade = new Button("Listar por Prioridade");
        Button btnListarTodas = new Button("Listar Todas");
        Button btnRelatorio = new Button("Ver Relatório");
        Button btnVoltarLogin = new Button("Voltar ao Login");

        btnAdicionar.setOnAction(e -> adicionarTarefa());
        btnAtualizar.setOnAction(e -> {
            Tarefa tarefaSelecionada = tableView.getSelectionModel().getSelectedItem();
            if (tarefaSelecionada != null) {
                atualizarTarefa(tarefaSelecionada);
            } else {
                exibirAlerta("Seleção Necessária", "Por favor, selecione uma tarefa para atualizar.");
            }
        });

        btnRemover.setOnAction(e -> {
            Tarefa tarefaSelecionada = tableView.getSelectionModel().getSelectedItem();
            if (tarefaSelecionada != null) {
                removerTarefa(tarefaSelecionada);
            } else {
                exibirAlerta("Seleção Necessária", "Por favor, selecione uma tarefa para remover.");
            }
        });

        btnConcluir.setOnAction(e -> {
            Tarefa tarefaSelecionada = tableView.getSelectionModel().getSelectedItem();
            if (tarefaSelecionada != null) {
                concluirTarefa(tarefaSelecionada);
            } else {
                exibirAlerta("Seleção Necessária", "Por favor, selecione uma tarefa para marcar como concluída.");
            }
        });

        btnListarStatus.setOnAction(e -> listarPorStatus());
        btnListarPrioridade.setOnAction(e -> listarPorPrioridade());
        btnListarTodas.setOnAction(e -> carregarTarefas());
        btnRelatorio.setOnAction(e -> RelatorioScreen.display(userId));

        btnVoltarLogin.setOnAction(e -> {
            stage.close();
            MainApp mainApp = new MainApp();
            Stage newStage = new Stage();
            try {
                mainApp.start(newStage);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        HBox buttonsTop = new HBox(10, btnAdicionar, btnAtualizar, btnRemover, btnConcluir);
        buttonsTop.setAlignment(Pos.CENTER);

        HBox buttonsBottom = new HBox(10, btnListarStatus, btnListarPrioridade, btnListarTodas, btnRelatorio, btnVoltarLogin);
        buttonsBottom.setAlignment(Pos.CENTER);

        VBox layout = new VBox(15, tableView, buttonsTop, buttonsBottom);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.CENTER);

        carregarTarefas();

        Scene scene = new Scene(layout, 800, 500);
        stage.setScene(scene);
        stage.show();
    }

    private static void carregarTarefas() {
        if (usuarioAtualId != null) {
            List<Tarefa> tarefas = tarefaRestClient.getTarefasByUserId(usuarioAtualId);
            tarefasList.setAll(tarefas);
        }
    }
    
    private static void removerTarefa(Tarefa tarefa) {
        if (tarefaRestClient.deleteTarefa(tarefa.getId())) {
            carregarTarefas();
            exibirAlerta("Sucesso", "Tarefa removida com sucesso!");
        } else {
            exibirAlerta("Erro", "Não foi possível remover a tarefa.");	
        }
    }

    private static void concluirTarefa(Tarefa tarefa) {
        if (tarefaRestClient.marcarComoConcluida(tarefa.getId())) {
            carregarTarefas();
            exibirAlerta("Sucesso", "Tarefa marcada como concluída!");
        } else {
            exibirAlerta("Erro", "Não foi possível marcar a tarefa como concluída.");
        }
    }

    private static void adicionarTarefa() {
        Stage stage = new Stage();
        stage.setTitle("Adicionar Tarefa");

        TextField txtTitulo = new TextField();
        txtTitulo.setPromptText("Título");
        TextField txtDescricao = new TextField();
        txtDescricao.setPromptText("Descrição");
        DatePicker dataInicio = new DatePicker(LocalDate.now());
        DatePicker dataFim = new DatePicker();
        ComboBox<Priority> cmbPrioridade = new ComboBox<>(FXCollections.observableArrayList(Priority.values()));
        cmbPrioridade.setValue(Priority.LOW);

        Button btnSalvar = new Button("Salvar");
        btnSalvar.setOnAction(e -> {
            if (!txtTitulo.getText().isEmpty()) {
                Tarefa novaTarefa = new Tarefa();
                novaTarefa.setTitulo(txtTitulo.getText());
                novaTarefa.setDescricao(txtDescricao.getText());
                novaTarefa.setDataInicio(dataInicio.getValue());
                novaTarefa.setDataFim(dataFim.getValue());
                novaTarefa.setPrioridade(cmbPrioridade.getValue());
                novaTarefa.setEstado(Status.PENDING);

                // Obtendo o ID do usuário associado à tarefa
                Long userId = (novaTarefa.getUser() != null) ? novaTarefa.getUser().getId() : usuarioAtualId;
                novaTarefa.setUser(new User());
                novaTarefa.getUser().setId(userId);

                boolean sucesso = tarefaRestClient.saveTarefa(userId, novaTarefa);
                if (sucesso) {
                    carregarTarefas();
                    exibirAlerta("Sucesso", "Tarefa adicionada com sucesso!");
                    stage.close();
                } else {
                    exibirAlerta("Erro", "Não foi possível adicionar a tarefa.");
                }
            } else {
                exibirAlerta("Erro", "O título da tarefa não pode estar vazio!");
            }
        });

        VBox layout = new VBox(10, txtTitulo, txtDescricao, dataInicio, dataFim, cmbPrioridade, btnSalvar);
        layout.setPadding(new Insets(20));

        Scene scene = new Scene(layout, 350, 300);
        stage.setScene(scene);
        stage.show();
    }


    private static void atualizarTarefa(Tarefa tarefa) {
        if (isUpdating) {
            return;
        }
        isUpdating = true;
        
        if (tarefa != null) {
            System.out.println("Tentando atualizar tarefa com ID: " + tarefa.getId());
            
            if (tarefa.getId() > 0) {
                Stage stage = new Stage();
                stage.setTitle("Atualizar Tarefa");

                TextField txtTitulo = new TextField(tarefa.getTitulo());
                TextField txtDescricao = new TextField(tarefa.getDescricao());
                DatePicker dataInicio = new DatePicker(tarefa.getDataInicio());
                DatePicker dataFim = new DatePicker(tarefa.getDataFim());
                ComboBox<Priority> cmbPrioridade = new ComboBox<>(FXCollections.observableArrayList(Priority.values()));
                cmbPrioridade.setValue(tarefa.getPrioridade());
                ComboBox<Status> cmbStatus = new ComboBox<>(FXCollections.observableArrayList(Status.values()));
                cmbStatus.setValue(tarefa.getEstado());

                Button btnSalvar = new Button("Salvar");
                btnSalvar.setOnAction(e -> {
                    tarefa.setTitulo(txtTitulo.getText());
                    tarefa.setDescricao(txtDescricao.getText());
                    tarefa.setDataInicio(dataInicio.getValue());
                    tarefa.setDataFim(dataFim.getValue());
                    tarefa.setPrioridade(cmbPrioridade.getValue());
                    tarefa.setEstado(cmbStatus.getValue());

                    boolean sucesso = tarefaRestClient.updateTarefa(tarefa.getId(), tarefa);
                    if (sucesso) {
                        carregarTarefas();
                        exibirAlerta("Sucesso", "Tarefa atualizada com sucesso!");
                        stage.close();
                    } else {
                        exibirAlerta("Erro", "Falha ao atualizar a tarefa. Verifique os dados e tente novamente.");
                    }
                });

                VBox layout = new VBox(10, txtTitulo, txtDescricao, dataInicio, dataFim, cmbPrioridade, cmbStatus, btnSalvar);
                layout.setPadding(new Insets(20));
                Scene scene = new Scene(layout, 350, 400);
                stage.setScene(scene);
                stage.show();
            } else {
                exibirAlerta("Erro", "ID da tarefa inválido. Verifique se a tarefa foi salva corretamente.");
            }
        } else {
            exibirAlerta("Erro", "Tarefa inválida para atualização.");
        }
        
        isUpdating = false;
    }

    

    private static void listarPorStatus() {
        ChoiceDialog<Status> dialog = new ChoiceDialog<>(Status.PENDING, Status.values());
        dialog.setTitle("Filtrar por Status");
        dialog.setHeaderText("Escolha um status para filtrar");
        dialog.setContentText("Status:");
        dialog.showAndWait().ifPresent(status -> {
            List<Tarefa> tarefasFiltradas = tarefaRestClient.getTarefasByStatus(usuarioAtualId, status);
            tarefasList.setAll(tarefasFiltradas);
        });
    }

    private static void listarPorPrioridade() {
        ChoiceDialog<Priority> dialog = new ChoiceDialog<>(Priority.LOW, Priority.values());
        dialog.setTitle("Filtrar por Prioridade");
        dialog.setHeaderText("Escolha uma prioridade para filtrar");
        dialog.setContentText("Prioridade:");
        dialog.showAndWait().ifPresent(prioridade -> {
            List<Tarefa> tarefasFiltradas = tarefaRestClient.getTarefasByPrioridade(usuarioAtualId, prioridade);
            tarefasList.setAll(tarefasFiltradas);
        });
    }

    private static void exibirAlerta(String titulo, String mensagem) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensagem);
        alert.showAndWait();
    }
}
