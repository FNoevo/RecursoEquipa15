package recurso;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.control.*;
import javafx.stage.Stage;
import pt.upt.ei.lp.rest.*;

public class RelatorioScreen {

    public static void display(Long userId) {
        Stage stage = new Stage();
        stage.setTitle("Relatório de Tarefas");

        Label lblTitulo = new Label("Relatório de Tarefas");
        TextArea txtRelatorio = new TextArea();
        txtRelatorio.setEditable(false);
        txtRelatorio.setWrapText(true);

        // Criar relatório automaticamente para o user logado
        String relatorio = gerarRelatorio(userId);
        txtRelatorio.setText(relatorio);

        Button btnFechar = new Button("Fechar");
        btnFechar.setOnAction(e -> stage.close());

        VBox layout = new VBox(10, lblTitulo, txtRelatorio, btnFechar);
        layout.setPadding(new Insets(20));

        Scene scene = new Scene(layout, 500, 400);
        stage.setScene(scene);
        stage.show();
    }

    private static String gerarRelatorio(Long userId) {
        TarefaRestClient tarefaRestClient = new TarefaRestClient();
        return tarefaRestClient.generateRelatorio(userId);
    }
}
