package recurso;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import pt.upt.ei.lp.model.User;
import pt.upt.ei.lp.rest.UserRestClient;

public class LoginScreen {

    private static UserRestClient userRestClient = new UserRestClient();

    public static void display() {
        Stage stage = new Stage();
        stage.setTitle("Login");

        Label lblUsername = new Label("Username:");
        TextField txtUsername = new TextField();

        Label lblPassword = new Label("Senha:");
        PasswordField txtPassword = new PasswordField();

        Button btnLogin = new Button("Entrar");
        btnLogin.setOnAction(e -> realizarLogin(txtUsername.getText(), txtPassword.getText(), stage));

        Button btnVoltar = new Button("Voltar");
        btnVoltar.setOnAction(e -> stage.close());

        Label lblMensagem = new Label();

        // Criar HBox para centralizar os botões
        HBox buttonBox = new HBox(10, btnLogin, btnVoltar);
        buttonBox.setAlignment(Pos.CENTER); // Centraliza os botões

        // Criar VBox principal
        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.CENTER); // Centraliza os elementos na vertical
        layout.getChildren().addAll(lblUsername, txtUsername, lblPassword, txtPassword, buttonBox, lblMensagem);

        Scene scene = new Scene(layout, 300, 250);
        stage.setScene(scene);
        stage.show();
    }

    private static void realizarLogin(String username, String senha, Stage stage) {
        User user = userRestClient.getUserByUsername(username);

        if (user != null && user.getPassword() != null && user.getPassword().equals(senha)) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Login");
            alert.setHeaderText(null);
            alert.setContentText("Login bem-sucedido!");
            alert.showAndWait();

            stage.close();
            Dashboard.display(user.getId());
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erro de Login");
            alert.setHeaderText(null);
            alert.setContentText("User ou senha incorretos!");
            alert.showAndWait();
        }
    }
}
