package recurso;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import pt.upt.ei.lp.model.*;
import pt.upt.ei.lp.rest.*;

public class RegistroScreen {

    public static void display() {
        Stage stage = new Stage();
        stage.setTitle("Registro");

        Label lblUsername = new Label("Username:");
        TextField txtUsername = new TextField();
        
        Label lblPassword = new Label("Senha:");
        PasswordField txtPassword = new PasswordField();
        
        Button btnRegistrar = new Button("Registrar");
        btnRegistrar.setOnAction(e -> realizarRegistro(txtUsername.getText(), txtPassword.getText()));
        
        Button btnVoltar = new Button("Voltar");
        btnVoltar.setOnAction(e -> stage.close());

        // Criar HBox para centralizar os botões
        HBox buttonBox = new HBox(10, btnRegistrar, btnVoltar);
        buttonBox.setAlignment(Pos.CENTER); // Centraliza os botões horizontalmente

        // Criar VBox principal
        VBox layout = new VBox(15);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.CENTER); // Centraliza tudo verticalmente
        layout.getChildren().addAll(lblUsername, txtUsername, lblPassword, txtPassword, buttonBox);

        Scene scene = new Scene(layout, 300, 250);
        stage.setScene(scene);
        stage.show();
    }

    private static void realizarRegistro(String username, String senha) {
        UserRestClient userRestClient = new UserRestClient();
        User newUser = new User();
        newUser.setUsername(username);
        newUser.setPassword(senha);
        
        boolean success = userRestClient.saveUser(newUser);
        if (success) {
            System.out.println("Registro bem-sucedido para: " + username);
        } else {
            System.out.println("Erro no registro");
        }
    }
}
