package recurso;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class MainApp extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Gestão de Tarefas");
        
        Button btnLogin = new Button("Login");
        btnLogin.setOnAction(e -> abrirTelaLogin());
        
        Button btnRegistro = new Button("Registo");
        btnRegistro.setOnAction(e -> abrirTelaRegistro());

        // Criar VBox e centralizar os elementos
        VBox layout = new VBox(15);
        layout.setAlignment(Pos.CENTER); // Centraliza os botões na vertical e horizontal
        layout.getChildren().addAll(btnLogin, btnRegistro);

        Scene scene = new Scene(layout, 300, 200);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void abrirTelaLogin() {
        LoginScreen.display();
    }
    
    private void abrirTelaRegistro() {
        RegistroScreen.display();
    }
    
    public static void main(String[] args) {
        launch(args);
    }
}
