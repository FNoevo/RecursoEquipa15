package pt.upt.ei.lp.rest;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import pt.upt.ei.lp.model.User;

public class UserRestClient {

	private RestTemplate restTemplate = new RestTemplate();
	private static final String userAPIURL = "http://localhost:8080/api/users";

	public List<User> getAllUsers() {
		ResponseEntity<User[]> response = restTemplate.getForEntity(userAPIURL, User[].class);
		List<User> users = new ArrayList<>();
		if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
			for (User u : response.getBody()) {
				users.add(u);
			}
		}
		return users;
	}

	public User getUserById(Long id) {
		ResponseEntity<User> response = restTemplate.getForEntity(userAPIURL + "/" + id, User.class);
		return response.getStatusCode().is2xxSuccessful() ? response.getBody() : null;
	}
	
    
    public User getUserByUsername(String username) {
        try {
            ResponseEntity<User> response = restTemplate.getForEntity(userAPIURL + "/username/" + username, User.class);
            return response.getStatusCode().is2xxSuccessful() ? response.getBody() : null;
        } catch (HttpClientErrorException.NotFound e) {
            System.out.println("Usuário não encontrado: " + username);
            return null;
        } catch (Exception e) {
            System.out.println("Erro ao buscar usuário: " + e.getMessage());
            return null;
        }
    }

	public boolean saveUser(User user) {
		ResponseEntity<User> response = restTemplate.postForEntity(userAPIURL, user, User.class);
		return response.getStatusCode().is2xxSuccessful();
	}

	public boolean deleteUser(Long id) {
		ResponseEntity<Void> response = restTemplate.exchange(userAPIURL + "/" + id, HttpMethod.DELETE, null, Void.class);
		return response.getStatusCode().is2xxSuccessful();
	}
}