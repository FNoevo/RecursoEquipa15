package pt.upt.ei.lp.rest;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import pt.upt.ei.lp.model.Tarefa;
import pt.upt.ei.lp.model.Tarefa.Priority;
import pt.upt.ei.lp.model.Tarefa.Status;

public class TarefaRestClient {

    private final RestTemplate restTemplate = new RestTemplate();
    private static final String rootAPIURL = "http://localhost:8080/api/tarefas";

    public List<Tarefa> getTarefasByUserId(Long userId) {
        ResponseEntity<Tarefa[]> response = restTemplate.getForEntity(
            rootAPIURL + "?userId=" + userId, Tarefa[].class
        );
        return processarListaResponse(response);
    }

    public Tarefa getTarefaById(Long id) {
        ResponseEntity<Tarefa> response = restTemplate.getForEntity(
            rootAPIURL + "/" + id, Tarefa.class
        );
        return response.getStatusCode().is2xxSuccessful() ? response.getBody() : null;
    }

    public List<Tarefa> getTarefasByPrioridade(Long userId, Priority prioridade) {
        ResponseEntity<Tarefa[]> response = restTemplate.getForEntity(
            rootAPIURL + "/prioridade/" + prioridade + "?userId=" + userId, Tarefa[].class
        );
        return processarListaResponse(response);
    }


    public List<Tarefa> getTarefasByStatus(Long userId, Status status) {
        ResponseEntity<Tarefa[]> response = restTemplate.getForEntity(
            rootAPIURL + "/status/" + status + "?userId=" + userId, Tarefa[].class
        );
        return processarListaResponse(response);
    }

    public String generateRelatorio(Long userId) {
        ResponseEntity<String> response = restTemplate.getForEntity(
            rootAPIURL + "/relatorio?userId=" + userId, String.class
        );
        return response.getStatusCode().is2xxSuccessful() ? response.getBody() : "Erro ao gerar relatório";
    }


    public boolean saveTarefa(Long userId, Tarefa tarefa) {
        ResponseEntity<Tarefa> response = restTemplate.postForEntity(
            rootAPIURL + "/users/" + userId, tarefa, Tarefa.class
        );
        return response.getStatusCode().is2xxSuccessful();
    }


    public boolean updateTarefa(Long id, Tarefa tarefa) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Tarefa> requestEntity = new HttpEntity<>(tarefa, headers);

        ResponseEntity<Tarefa> response = restTemplate.exchange(
            rootAPIURL + "/" + id, HttpMethod.PUT, requestEntity, Tarefa.class
        );

        return response.getStatusCode().is2xxSuccessful();
    }


    public boolean marcarComoConcluida(Long id) {
        ResponseEntity<Tarefa> response = restTemplate.exchange(
            rootAPIURL + "/" + id + "/concluir", HttpMethod.PUT, null, Tarefa.class
        );
        return response.getStatusCode().is2xxSuccessful();
    }

    public boolean deleteTarefa(Long id) {
        ResponseEntity<Void> response = restTemplate.exchange(
            rootAPIURL + "/" + id, HttpMethod.DELETE, null, Void.class
        );
        return response.getStatusCode().is2xxSuccessful();
    }


    private List<Tarefa> processarListaResponse(ResponseEntity<Tarefa[]> response) {
        List<Tarefa> tarefas = new ArrayList<>();
        if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null) {
            for (Tarefa t : response.getBody()) {
                tarefas.add(t);
            }
        }
        return tarefas;
    }
}
