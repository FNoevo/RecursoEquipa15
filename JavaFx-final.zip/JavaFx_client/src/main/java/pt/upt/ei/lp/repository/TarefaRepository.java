package pt.upt.ei.lp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pt.upt.ei.lp.model.Tarefa;
import pt.upt.ei.lp.model.Tarefa.Priority;
import pt.upt.ei.lp.model.Tarefa.Status;
import java.util.List;

@Repository
public interface TarefaRepository extends JpaRepository<Tarefa, Long> {
    List<Tarefa> findByPrioridade(Priority prioridade);
    List<Tarefa> findByStatus(Status status);
}
