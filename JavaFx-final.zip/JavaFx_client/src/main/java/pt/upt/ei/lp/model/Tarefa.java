package pt.upt.ei.lp.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import com.fasterxml.jackson.annotation.JsonBackReference;
import javafx.beans.property.*;

@Entity
@Table(name = "tarefas")
public class Tarefa {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(nullable = false)
    private String titulo;

    private String descricao;

    @Column(name = "data_inicio")
    private LocalDate dataInicio;

    @Column(name = "data_fim")
    private LocalDate dataFim;

    @Enumerated(EnumType.STRING)
    private Priority prioridade;

    @Enumerated(EnumType.STRING)
    private Status status;

    @ManyToOne
    @JoinColumn(name = "user_id", referencedColumnName = "id")
    @JsonBackReference
    private User user;
    
    public Tarefa() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public StringProperty tituloProperty() {
        return new SimpleStringProperty(titulo);
    }
    
    public ObjectProperty<LocalDate> dataInicioProperty() {
        return new SimpleObjectProperty<>(dataInicio);
    }

    public ObjectProperty<LocalDate> dataFimProperty() {
        return new SimpleObjectProperty<>(dataFim);
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public StringProperty descricaoProperty() {
        return new SimpleStringProperty(descricao);
    }

    public LocalDate getDataInicio() {
        return dataInicio;
    }

    public void setDataInicio(LocalDate dataInicio) {
        this.dataInicio = dataInicio;
    }

    public LocalDate getDataFim() {
        return dataFim;
    }

    public void setDataFim(LocalDate dataFim) {
        this.dataFim = dataFim;
    }

    public Priority getPrioridade() {
        return prioridade;
    }

    public void setPrioridade(Priority prioridade) {
        this.prioridade = prioridade;
    }

    public ObjectProperty<Priority> prioridadeProperty() {
        return new SimpleObjectProperty<>(prioridade);
    }

    public Status getEstado() {
        return status;
    }

    public void setEstado(Status status) {
        this.status = status;
    }

    public ObjectProperty<Status> estadoProperty() {
        return new SimpleObjectProperty<>(status);
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
    
    public enum Priority {
        LOW, MEDIUM, HIGH;
    }

    public enum Status {
        PENDING, COMPLETED;
    }

    @Override
    public String toString() {
        return "Tarefa [id=" + id + ", titulo=" + titulo + ", descricao=" + descricao + ", dataInicio=" + dataInicio
                + ", dataFim=" + dataFim + ", prioridade=" + prioridade + ", status=" + status + ", user=" + user + "]";
    }
}