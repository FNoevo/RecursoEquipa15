package com.upt.lp.restapi.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.upt.lp.restapi.model.Tarefa;
import com.upt.lp.restapi.model.User;
import com.upt.lp.restapi.model.Tarefa.Priority;
import com.upt.lp.restapi.model.Tarefa.Status;
import com.upt.lp.restapi.repository.TarefaRepository;
import com.upt.lp.restapi.repository.UserRepository;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class TarefaService {
    @Autowired
    private TarefaRepository tarefaRepository;

    @Autowired
    private UserRepository userRepository;

    public List<Tarefa> getAllTarefas() {
        return tarefaRepository.findAll();
    }

    public Optional<Tarefa> getTarefaById(Long id) {
        return tarefaRepository.findById(id);
    }
    
    public List<Tarefa> getTarefasByUserId(Long userId) {
        return tarefaRepository.findByUserId(userId);
    }

    public Tarefa createTarefa(Long userId, Tarefa tarefa) {
        return userRepository.findById(userId).map(user -> {
            tarefa.setUser(user);
            return tarefaRepository.save(tarefa);
        }).orElseThrow(() -> new RuntimeException("Usuário não encontrado com ID: " + userId));
    }

    public Tarefa updateTarefa(Long id, Tarefa tarefaDetails) {
        return tarefaRepository.findById(id).map(tarefa -> {
            tarefa.setTitulo(tarefaDetails.getTitulo());
            tarefa.setDescricao(tarefaDetails.getDescricao());
            tarefa.setDataFim(tarefaDetails.getDataFim());
            tarefa.setPrioridade(tarefaDetails.getPrioridade());
            tarefa.setEstado(tarefaDetails.getEstado());
            return tarefaRepository.save(tarefa);
        }).orElseThrow(() -> new RuntimeException("Tarefa não encontrada com ID: " + id));
    }

    public void deleteTarefa(Long id) {
        if (tarefaRepository.existsById(id)) {
            tarefaRepository.deleteById(id);
        } else {
            throw new RuntimeException("Tarefa não encontrada com ID: " + id);
        }
    }    

    public List<Tarefa> getTarefasByUserAndPrioridade(Long userId, Tarefa.Priority prioridade) {
        return tarefaRepository.findByUserIdAndPrioridade(userId, prioridade);
    }

    public List<Tarefa> getTarefasByUserAndStatus(Long userId, Tarefa.Status status) {
        return tarefaRepository.findByUserIdAndStatus(userId, status);
    }


    public Tarefa marcarComoConcluida(Long id) {
        return tarefaRepository.findById(id).map(tarefa -> {
            tarefa.setEstado(Status.COMPLETED);
            return tarefaRepository.save(tarefa);
        }).orElseThrow(() -> new RuntimeException("Tarefa não encontrada com ID: " + id));
    } 
    
    public String generateRelatorio(Long userId) {
        List<Tarefa> tarefas = (userId != null) 
            ? tarefaRepository.findByUserId(userId) 
            : tarefaRepository.findAll();

        if (tarefas.isEmpty()) {
            return "Nenhuma tarefa encontrada para o usuário " + (userId != null ? userId : "no sistema.");
        }

        int totalTarefas = tarefas.size();

        Map<Priority, Long> prioridadeCount = tarefas.stream()
                .collect(Collectors.groupingBy(Tarefa::getPrioridade, Collectors.counting()));

        Map<Status, Long> estadoCount = tarefas.stream()
                .collect(Collectors.groupingBy(Tarefa::getEstado, Collectors.counting()));

        StringBuilder relatorio = new StringBuilder();

        if (userId != null) {
            relatorio.append("Relatório de Tarefas para o Usuário ID: ").append(userId).append("\n");
        } else {
            relatorio.append("Relatório de Tarefas Geral\n");
        }

        relatorio.append("Total de Tarefas: ").append(totalTarefas).append("\n\n");

        relatorio.append("Porcentagem por Prioridade:\n");
        for (Priority prioridade : Priority.values()) {
            long count = prioridadeCount.getOrDefault(prioridade, 0L);
            double percentage = (totalTarefas > 0) ? (count * 100.0 / totalTarefas) : 0.0;
            relatorio.append(prioridade).append(": ").append(String.format("%.2f%%", percentage)).append("\n");
        }

        relatorio.append("\nPorcentagem por Estado:\n");
        for (Status status : Status.values()) {
            long count = estadoCount.getOrDefault(status, 0L);
            double percentage = (totalTarefas > 0) ? (count * 100.0 / totalTarefas) : 0.0;
            relatorio.append(status).append(": ").append(String.format("%.2f%%", percentage)).append("\n");
        }

        return relatorio.toString();
    }
}
